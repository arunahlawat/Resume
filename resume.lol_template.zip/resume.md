<!--
Welcome to resume.lol!

This is the template you can use to get started.

Full credit for this template goes to Jake. Original template is in LaTeX here:

https://www.overleaf.com/latex/templates/jakes-resume/syzfjbzwjncs

------

Easily remove personal info by using a variable follow with a second value and "||":

@NAME=Real Name||Hidden Name

and change @REDACTED to be true

@REDACTED=true
-->
@REDACTED=false
@NAME=ARUN
@EMAIL=arunahlawat1996@gmail.com
@PHONE=8467883584
@LINKEDIN=arunahlawat1996
@GITHUB=arunahlawat

# {NAME}

<div class="section headerInfo">

- {PHONE}
- [{EMAIL}](mailto:{EMAIL})
- [linkedin.com/in/{LINKEDIN}](https://linkedin.com/in/{LINKEDIN})
- [github.com/{GITHUB}](https://github.com/{GITHUB})

</div>

*Detail-oriented and analytical recent graduate with Strong foundation in **ETL**. Proficient in **SQL, Python, Informatica, Power BI** and data interpretation. Adept at dashboard creation and data visualization, with a passion for deriving insights from complex datasets. Eager to apply knowledge and skills to deliver valuable insights and support data-driven decision-making.*

## **Education**


### Chandigarh University <span class="spacer"></span><span class="normal">2016 &ndash; 2020</span>
#### BE (CSE)   CGPA- 7.36<span class="spacer"></span>Mohali, IN
### Ganga International School <span class="spacer"></span><span class="normal">2013 &ndash; 2015</span>
#### 12th | CBSE   81.2%<span class="spacer"></span>Delhi, IN
#### 10th | CBSE   CGPA- 9.0
## **Experience**

### Capgemini India (GE Healthcare) <span class="spacer"></span><span class="normal"> Oct 2020 &ndash; Present </span>

#### Associate Consultant (May 2023 – present)

- Modify, enhance, and develop simple to complex parameterized mappings in Informatica PowerCenter using various loading strategies like ,**SCD-1, SCD-2, Delete & Insert**, etc.
- Ingest data into **ORACLE DW** coming from various source systems in the form of delimited flat files or directly from the source database using **Informatica PowerCenter** and **UNIX**.
- Develop medium to complex SQL views in ORACLE and use them as source in ETL mappings to extract their data into delimited files, compatible.


#### Sr. Analyst (Jan 2022 – Apr 2023)

- Develop jobs using **CRONACLE** tool which validate data between multiple tables belonging to same or different database using ORACLE & Informatica PowerCenter, with an automated email generation process through **UNIX Shell Scripting**.
- Develop Reports in **PowerBI, Tableau and Spotfire** as per client Requirements.
- Manage & carry out the Informatica, Database and UNIX deployment activity as per the steps provided in the Deployment documents & Change tickets.

#### Analyst (Oct 2020 – Dec 2021)

- Monitor 1000+ ETL Informatica daily jobs built on UNIX server & rectify them spontaneously when failures/issues occur.
- Perform deep dive Data Analysis using SQL, when issues/discrepancies reported by users in Production environment.
- Work on **ServiceNow** incident, problem & change tickets with proper understanding of the ITIL service management concepts

## **Technical Skills**

<span class="indent"></span>**Languages**: Python, SQL, PostgreSQL, PL/SQL, UNIX

<span class="indent"></span>**Database**: Oracle, Teradata, MySQL, PostgreSQL

<span class="indent"></span>**Tools**: Excel, PowerBI, Tableau, Informatica, WinSCP, Putty, Cronacle, Spotfire

<span class="indent"></span>**Libraries**: pandas, NumPy, Matplotlib, Seaborn


## **Projects**
### [Economic Data Analysis](https://github.com/arunahlawat/Python-Economic-Data-Analysis)<span class="tech-stack">&nbsp;| *Numpy, Pandas, Seaborn and Matplotlib*</span><span class="spacer"></span><span class="normal"></span>

### [Advance Excel Projects](https://github.com/arunahlawat/Excel-Projects)<span class="tech-stack">&nbsp;| *Pivot Table, Charts, Maps, Slicers, Data Validation, Slicers*</span><span class="spacer"></span><span class="normal"></span>
### [Library Management](https://github.com/arunahlawat/PL-SQL-project-Library-Management)<span class="tech-stack">&nbsp;| *PL/SQL, SQL*</span><span class="spacer"></span><span class="normal"></span>
### [Adventure Works](https://github.com/arunahlawat/Power-BI-Dashboard-Adventure-Works)<span class="tech-stack">&nbsp;| *DAX, PowerBI, Data Modeling*</span><span class="spacer"></span><span class="normal"></span>

## **Rewards and Recognition**
### Rising Star Q1 2023
### [Badge for Data Science and AI](https://www.credly.com/badges/d4dc14e6-bafb-43a4-a3c5-8a6e376dda83)